import java.lang.*;
import frames.*;

public class Start
{
	public static void main(String args[])
	{
		LoginFrame lg = new LoginFrame();
		lg.setVisible(true);
	}
}